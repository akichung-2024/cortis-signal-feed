# CORTIS : SIGNAL v4.0 AUTO SYNC

## Setup
1. Create a **public** GitHub repository, e.g. `cortis-signal-feed`.
2. Upload `update_feed.py` and `.github/workflows/update.yml` preserving paths.
3. In **Settings → Pages → Build and deployment**, set **Source: GitHub Actions**.
4. In **Actions**, run **Update CORTIS news feed → Run workflow** once.
5. Your feed URL will be `https://YOUR_GITHUB_USERNAME.github.io/cortis-signal-feed/feed.json` (replace both username and repository name). Check it in Safari first.
6. In the Scriptable app, choose **連接自動更新資料源**, paste that HTTPS URL, then preview the widget.

## Limits
- Updates are *attempted* hourly by GitHub Actions; GitHub can delay scheduled runs, and iOS controls widget refresh times.
- Google News RSS results are **third-party news-search results**, not verified official announcements or Weverse posts.
- Weverse, Spotify shared songs, schedules and member-recommended books are **not automatically ingested** in this version. Those sections clearly show unsupported status rather than fake entries.
- No password, session cookie, Weverse login, or Spotify token should be shared.
