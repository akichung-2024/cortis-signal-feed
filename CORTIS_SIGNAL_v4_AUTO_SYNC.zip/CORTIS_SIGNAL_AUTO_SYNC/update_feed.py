#!/usr/bin/env python3
"""Collect public news-search results; do not represent them as official artist posts."""
import datetime as dt, email.utils, json, re, urllib.parse, urllib.request, xml.etree.ElementTree as ET
from pathlib import Path
NOW=dt.datetime.now(dt.timezone.utc)
QUERIES={'GROUP':'"CORTIS" (Kpop OR HYBE OR BIGHIT OR 코르티스)', 'MARTIN':'"CORTIS" "MARTIN"', 'JAMES':'"CORTIS" "JAMES"', 'JUHOON':'"CORTIS" "JUHOON"', 'SEONGHYEON':'"CORTIS" "SEONGHYEON"', 'KEONHO':'"CORTIS" "KEONHO"'}
HEADERS={'User-Agent':'Mozilla/5.0 (compatible; CORTIS-SIGNAL/4.0; public RSS reader)'}
items=[]; errors=[]; seen=set()
for member,query in QUERIES.items():
    url='https://news.google.com/rss/search?'+urllib.parse.urlencode({'q':query,'hl':'ko','gl':'KR','ceid':'KR:ko'})
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers=HEADERS),timeout=20) as r:
            root=ET.fromstring(r.read(1_500_000))
        for entry in root.findall('./channel/item')[:15]:
            title=(entry.findtext('title') or '').strip(); link=(entry.findtext('link') or '').strip()
            source=(entry.findtext('source') or 'Google News').strip()
            if not link.startswith('https://') or not re.search(r'CORTIS|코르티스',title,re.I):continue
            key=link
            if key in seen:continue
            seen.add(key)
            rawdate=entry.findtext('pubDate') or ''
            try: published=email.utils.parsedate_to_datetime(rawdate).astimezone(dt.timezone.utc)
            except (ValueError,TypeError):continue
            if published < NOW-dt.timedelta(days=45) or published > NOW+dt.timedelta(days=1):continue
            items.append({'kind':'news','member':member,'title':title[:180], 'source':source[:80], 'url':link, 'publishedAt':published.isoformat(), 'verification':'news_search_result'})
    except Exception as exc:errors.append(f'{member}: {type(exc).__name__}')
items.sort(key=lambda x:x['publishedAt'],reverse=True)
output={'schemaVersion':1,'updatedAt':NOW.isoformat(),'status':'ok' if not errors else 'partial','description':'Public news search results, NOT verified official Weverse or artist statements.','items':items[:100]}
Path('feed.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
print('items:',len(items),'errors:',errors)
